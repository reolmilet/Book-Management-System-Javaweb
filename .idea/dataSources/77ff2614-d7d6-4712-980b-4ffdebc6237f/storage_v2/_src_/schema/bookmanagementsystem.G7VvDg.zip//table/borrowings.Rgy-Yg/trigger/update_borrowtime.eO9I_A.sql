create definer = root@localhost trigger update_borrowtime
    before update
    on borrowings
    for each row
    SET NEW.borrowtime = DATEDIFF(NEW.return_date, NEW.borrow_date);

